#!/bin/bash

RD="initrd"
SYS="../system"
DESTDIR="$RD"

. /usr/share/initramfs-tools/hook-functions

pushd "$RD/bin"
./busybox --help |grep -A 100 "Currently defined functions" |grep "," |tr -d "\n" |sed -e "s|\s||g" |tr "," "\n" |while read b; do
    if [ ! -e "$b" ]; then
        ln -s busybox "$b"
    fi
done
popd

for i in atftp cp rsync ctorrent readlink tar vim.basic nbd-client; do
    rm -f "$RD/bin/$i"

    for s in "$SYS/usr/sbin/$i" "$SYS/usr/bin/$i" "$SYS/sbin/$i" "$SYS/bin/$i"; do
        if [ -e "$s" ]; then
            copy_exec "$s" "/bin"
            break
        fi
    done
done
mv "$RD/bin/vim.basic" "$RD/bin/vim"

mkdir -p "$RD/home/root"
